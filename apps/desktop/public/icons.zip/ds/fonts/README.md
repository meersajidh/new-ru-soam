# Fonts

| Family             | Role            | Weights pulled    | License            |
|--------------------|-----------------|-------------------|--------------------|
| **Source Serif 4** | Display + long-form body | 400 / 500 / 600 / 700 | SIL OFL (Adobe Originals → open release) |
| **Inter Tight**    | UI sans (workbench, forms, chrome) | 400 / 500 / 600 / 700 | SIL OFL |
| **IBM Plex Mono**  | Mono — recovery words, inline code, snippet placeholders | 400 / 500 | SIL OFL |

All three are open-licensed so they can ship inside an Electron bundle without legal review.

## Why this pairing

- **Source Serif 4** carries the brand. It's literary, calm, and supports **optical sizing** — at 18px the strokes thin and the spacing opens up; at 14px the strokes thicken to stay readable. That mirrors the brand line *"a careful structure, suspended quietly between you and the work"* — display when announcing, prose when reading.
- **Inter Tight** is the workbench sans. Tighter set-widths than vanilla Inter, which matches the codebase's dense 13/12/11 px size scale better. Pairs cleanly with Source Serif's optical scaling.
- **IBM Plex Mono** replaces JetBrains Mono. Plex Mono has subtle slab feet and a slightly warmer character — it reads more like a typewriter than a code editor, which fits a *clinician writing notes*. JetBrains Mono is great for code; Plex Mono is great for prose containing code-shaped tokens (`/hpi`, recovery words, resource URIs).

## Currently loaded via CDN

`google-fonts.css` issues a single `@import` against Google's `css2` endpoint. The browser fetches `.woff2` files at runtime. This is fine for design-review and prototyping; for the production Electron build the user should:

1. Download the `.woff2` files (or use `fontsource` packages on npm).
2. Drop them into `fonts/` next to this file.
3. Replace `google-fonts.css` with explicit `@font-face` declarations so the app doesn't reach the network on startup.

The font-set files (`../font-sets/*.css`) reference the families by name; nothing else needs to change.

## Substitution flag

The shipped app in `src/styles/font-sets/system-sans.css` uses only `system-ui`. The three families above are **proposed additions**, not yet wired into the codebase. Confirm and I'll add them to `src/index.css`, mirror the font-set CSS into `src/styles/font-sets/`, and register them in `src/platform/font/font-sets/built-in.ts`.
