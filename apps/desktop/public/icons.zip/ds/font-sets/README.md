# Font sets

A font set is a class on `<html>` that swaps the three font-family variables (`--font-sans`, `--font-mono`, `--font-display`). The codebase ships one set today; this folder defines two more, designed around the Lepcha cane-bridge brand story.

| Class | What it swaps | Use it for |
|---|---|---|
| `font-set-system-sans` | system stack, no webfonts | the default; safe fallback if webfonts fail |
| `font-set-ru-display`  | Inter Tight + Source Serif 4 + IBM Plex Mono | **recommended default** — brand-elevated workbench |
| `font-set-ru-editorial`| same families, but Source Serif also runs the patient-note body | clinicians who want the editor canvas to feel like a reading room |

## How to apply

```html
<html class="theme-bamboo dark font-set-ru-display">
```

The classes are mutually exclusive — only one font-set should be active at a time. `FontService` in `src/platform/font/font-service.ts` already handles this swap; once these sets are wired into `built-in.ts`, the user can switch via the command palette.

## Anatomy

Each set sets the three families plus two optional knobs:

| Variable | Purpose |
|---|---|
| `--font-sans`    | every chrome class (`.btn`, `.lbl`, `.editor-tab`, `.statusbar-entry`, body) |
| `--font-mono`    | recovery words, inline code, snippet placeholders, resource URIs |
| `--font-display` | hero headings (`.setup-title`, `.gate-title`, the patient-note `h1`) |
| `--font-display-weight` | weight applied by `.t-display` / `.t-title` recipes |
| `--font-display-letter-spacing` | tracking applied to display class recipes |

Layouts pin sizes; the font set picks the family. That means switching a set never reflows the workbench — only the typeface changes.

## Webfonts

Webfonts are loaded by `fonts/google-fonts.css` (Google Fonts CDN, single `@import`). See `fonts/README.md` for the production migration plan (download `.woff2`, replace the import with explicit `@font-face` declarations).

## Wiring this into `src/`

When confirmed, do these four things in the codebase:

1. **Copy this folder** into `src/styles/font-sets/` (replacing the stub `system-sans.css`).
2. **Add the `@import`** of `fonts/google-fonts.css` to `src/index.css`, near the top.
3. **Register the sets** in `src/platform/font/font-sets/built-in.ts` — three entries: `system-sans` (existing), `ru-display`, `ru-editorial`.
4. **Default** the cold-start font to `ru-display` in `src/platform/font/themes/initial-theme.ts` (or whichever module seeds the bootstrap font set — `applyInitialTheme` in `src/main.tsx`'s import chain).
