/* WorkspacePicker — square-tile grid. Three columns, 1:1 aspect ratio.
 * The "+ Add workspace" tile shares the same footprint with a dashed border. */

const TONES = ['', 'tone-amber', 'tone-violet', 'tone-teal', 'tone-rose'];

function WorkspacePicker({ workspaces, onSelect, onAddNew, activeId, loadingId }) {
  return (
    <div className="setup-page">
      <div className="picker-container">
        <div className="picker-header">
          <h1 className="setup-title">Choose a workspace</h1>
          <Description>Select a workspace to unlock, or add a new one.</Description>
        </div>
        <ul className="picker-grid">
          {workspaces.map((ws, i) => {
            const isActive = ws.id === activeId;
            const isLoading = ws.id === loadingId;
            const tone = TONES[i % TONES.length];
            return (
              <li key={ws.id} style={{ display: 'contents' }}>
                <button
                  className={`picker-tile ${isActive ? 'is-active' : ''}`}
                  onClick={() => onSelect(ws)}
                  aria-busy={isLoading}
                >
                  <span className={`picker-avatar ${tone}`}>{ws.nickname[0].toUpperCase()}</span>
                  <span className="picker-body">
                    <span className="picker-nickname">{ws.nickname}</span>
                    <span className="picker-tile-meta">{ws.lastSeen}</span>
                  </span>
                  <span className="picker-foot">
                    <span className="picker-stat">
                      <span className="ico"><Icon name="file-text" size={11} /></span>
                      {ws.noteCount?.toLocaleString() ?? '—'} notes
                    </span>
                    {isLoading ? (
                      <span className="picker-spinner" aria-hidden="true" />
                    ) : isActive ? (
                      <span className="picker-status is-current">Recent</span>
                    ) : (
                      <span className="picker-status">
                        <Icon name="lock" size={9} /> Locked
                      </span>
                    )}
                  </span>
                </button>
              </li>
            );
          })}
          <li style={{ display: 'contents' }}>
            <button className="picker-tile is-add" onClick={onAddNew}>
              <span className="picker-add-icon"><Icon name="plus" size={20} /></span>
              <span className="picker-add-label">Add workspace</span>
              <span /> {/* spacer to keep the same three-row vertical rhythm */}
            </button>
          </li>
        </ul>
      </div>
    </div>
  );
}

Object.assign(window, { WorkspacePicker });
