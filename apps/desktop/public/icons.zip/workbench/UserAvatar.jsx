/* UserAvatar — titlebar avatar with dropdown menu. */

const { useState: av_useState, useRef: av_useRef, useEffect: av_useEffect } = React;

function UserAvatar({ email, nickname, onRelock, onSignOut }) {
  const [open, setOpen] = av_useState(false);
  const btnRef = av_useRef(null);
  const menuRef = av_useRef(null);

  av_useEffect(() => {
    if (!open) return;
    function onDoc(e) {
      if (!menuRef.current?.contains(e.target) && !btnRef.current?.contains(e.target)) setOpen(false);
    }
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, [open]);

  const initial = (email?.[0] || nickname?.[0] || '?').toUpperCase();

  return (
    <div style={{ position: 'relative' }}>
      <button
        ref={btnRef}
        className="avatar-btn"
        onClick={() => setOpen(v => !v)}
        title={email}
      >
        {initial}
      </button>
      {open && (
        <div ref={menuRef} className="avatar-menu" role="menu">
          <div className="avatar-menu-header">
            <p className="avatar-menu-nick">{nickname}</p>
            <p className="avatar-menu-email">{email}</p>
          </div>
          <button className="avatar-menu-item" onClick={() => { setOpen(false); onRelock?.(); }}>
            <Icon name="lock" size={13} /> Lock workspace
          </button>
          <button className="avatar-menu-item">
            <Icon name="settings" size={13} /> Change passphrase…
          </button>
          <button className="avatar-menu-item" onClick={() => { setOpen(false); onSignOut?.(); }}>
            <Icon name="chevron-right" size={13} /> Sign out
          </button>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { UserAvatar });
