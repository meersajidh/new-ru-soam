# Workbench UI kit

Click-through, hi-fi recreation of the Ru-Soam Electron app's four product surfaces — all in one HTML file.

## Surfaces

| Screen     | What it shows                                                          | Source it mirrors                                  |
|------------|------------------------------------------------------------------------|----------------------------------------------------|
| Workbench  | Unlocked editor with patient sidebar, tabs, snippet chips, command palette | `src/workbench/Workbench.tsx` and its children     |
| Gate       | Locked workspace — passphrase entry + recovery-code fallback           | `src/workbench/middle/UnlockGate.tsx`              |
| Picker     | Workspace selector tiles + "Add new"                                   | `src/routes/workspaces/index.tsx`                  |
| Setup      | Five-step ceremony (sign in → nickname → passphrase → recovery → finish) | `src/routes/setup/keys.tsx`                        |

Use the floating switcher in the bottom-right to jump between them. **The switcher is not part of the product** — it exists only because the kit is one HTML file showing every surface.

## Files

- `index.html` — entry; loads React 18, Babel standalone, all .jsx scripts
- `ds.css` — kit-local stylesheet (imports tokens from `../../colors_and_type.css`)
- `Icon.jsx` — Lucide subset (icons we use, inlined as paths)
- `Bits.jsx` — buttons, inputs, label, description, strength meter
- `Chrome.jsx` — TitleBar, ActivityBar, PrimarySideBar (Patients / Snippets / Search), StatusBar
- `UserAvatar.jsx` — titlebar avatar + dropdown
- `Editor.jsx` — TabStrip + EmptyEditor + PatientNote (the clinical scene with snippet chips)
- `Palette.jsx` — command palette overlay
- `Setup.jsx` — five-step ceremony + mock Google modal
- `Picker.jsx` — workspace tiles
- `Gate.jsx` — locked-workspace gate
- `App.jsx` — top-level orchestrator + screen switcher

## What's faithful, what's elevated

**Faithful** to the codebase:
- Every CSS token and theme palette
- Every component layout and spacing
- Every microcopy string and voice pattern
- Five-step ceremony order and validation rules
- StatusBar contents, TitleBar buttons, ActivityBar slot system
- Snippet chip visual treatment (text-fill vs picklist), trigger via `/abbrev`

**Elevated** (proposals — not yet wired into `src/`):
- Brand display family (Source Serif 4) applied to setup, picker, unlock-gate, note H1
- Inter Tight + JetBrains Mono replace the system stack
- Lucide icons replace bracketed `[L]` / `[U]` glyphs and unicode window controls
- A small wordmark — `Ru / cane-rule / Soam` — sits in the TitleBar
- Empty editor state shows a weave-motif card and a short prompt
- StatusBar lock entry pairs a Lucide `lock` icon with the word `Locked` instead of the bracketed `[L]`

If any of these elevations should be backed out (or kept and shipped), let me know and I'll wire them into `src/styles/font-sets/`, `src/workbench/parts/`, etc.

## Components NOT recreated (yet)
- The Banner part (zero-height in the codebase; only relevant when warning entries are injected)
- The Panel part (bottom dock; not used in the current shipped screens)
- The AuxSideBar (right rail; same)
- The Prefs dev panel (developer-only)
- The Change-passphrase dialog (subtree of the avatar menu — visually the same as the OAuth modal)

These are easy follow-ups if the design needs them.
