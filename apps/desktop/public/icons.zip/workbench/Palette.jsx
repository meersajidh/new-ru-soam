/* CommandPalette — overlay with categorised, filterable items. */

const { useState: cp_useState, useEffect: cp_useEffect, useRef: cp_useRef } = React;

const COMMANDS = [
  { id: 'workbench.workspace.relock', title: 'Lock Workspace',        category: 'View',      kbd: '⌘⇧L' },
  { id: 'workbench.workspace.switch', title: 'Switch Workspace…',     category: 'View',      kbd: ''     },
  { id: 'view.toggleSidebar',         title: 'Toggle Side Bar',       category: 'View',      kbd: '⌘B'   },
  { id: 'view.togglePanel',           title: 'Toggle Panel',          category: 'View',      kbd: '⌘J'   },
  { id: 'editors.nextTab',            title: 'Next Tab',              category: 'Editor',    kbd: '⌘⌥→'  },
  { id: 'editors.previousTab',        title: 'Previous Tab',          category: 'Editor',    kbd: '⌘⌥←'  },
  { id: 'editors.close',              title: 'Close Tab',             category: 'Editor',    kbd: '⌘W'   },
  { id: 'snippets.insert.hpi',        title: 'Insert: History of Present Illness', category: 'Snippet', kbd: '/hpi' },
  { id: 'snippets.insert.pe',         title: 'Insert: Physical Exam', category: 'Snippet',   kbd: '/pe'  },
  { id: 'snippets.insert.disp',       title: 'Insert: Disposition',   category: 'Snippet',   kbd: '/disp'},
  { id: 'developer.snippets.seed',    title: 'Seed Snippet Registry', category: 'Developer', kbd: ''     },
  { id: 'developer.lock.dumpState',   title: 'Dump Lock State',       category: 'Developer', kbd: ''     },
  { id: 'developer.lock.forceRelock', title: 'Force Relock Workspace',category: 'Developer', kbd: ''     },
];

function CommandPalette({ open, onClose }) {
  const [q, setQ] = cp_useState('');
  const [sel, setSel] = cp_useState(0);
  const inputRef = cp_useRef(null);

  cp_useEffect(() => {
    if (open) {
      setQ(''); setSel(0);
      // setTimeout: wait for the overlay to mount before focusing
      setTimeout(() => inputRef.current?.focus(), 10);
    }
  }, [open]);

  if (!open) return null;

  const ql = q.toLowerCase();
  const visible = COMMANDS.filter(c =>
    !ql || c.title.toLowerCase().includes(ql) || c.category.toLowerCase().includes(ql)
  );

  function handleKey(e) {
    if (e.key === 'Escape') { e.preventDefault(); onClose(); }
    if (e.key === 'ArrowDown') { e.preventDefault(); setSel(i => Math.min(i + 1, visible.length - 1)); }
    if (e.key === 'ArrowUp')   { e.preventDefault(); setSel(i => Math.max(i - 1, 0)); }
    if (e.key === 'Enter' && visible[sel]) { e.preventDefault(); onClose(); }
  }

  return (
    <div className="cmd-palette-overlay" onMouseDown={onClose}>
      <div className="cmd-palette" role="dialog" aria-modal="true" onMouseDown={e => e.stopPropagation()}>
        <div className="cmd-palette-input">
          <Icon name="command" size={14} color="var(--color-fg-muted)" />
          <input
            ref={inputRef}
            placeholder="Type a command…"
            value={q}
            onChange={e => { setQ(e.target.value); setSel(0); }}
            onKeyDown={handleKey}
          />
        </div>
        <ul className="cmd-palette-list">
          {visible.length === 0 ? (
            <li className="cmd-palette-item" style={{ color: 'var(--color-fg-muted)' }}>No commands found</li>
          ) : visible.map((c, i) => (
            <li
              key={c.id}
              className={`cmd-palette-item ${i === sel ? 'is-sel' : ''}`}
              onMouseEnter={() => setSel(i)}
              onClick={onClose}
            >
              <span className="cmd-palette-cat">{c.category}:</span>
              <span>{c.title}</span>
              {c.kbd && <span className="cmd-palette-keybind">{c.kbd}</span>}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

Object.assign(window, { CommandPalette });
