/* Editor — TabStrip + ru-edit clinical note scene with snippet chips.
 *
 * The note's "live" parts: a text placeholder ({chief_complaint}) the user is
 * currently editing, and a picklist placeholder for the disposition. Clicking
 * the picklist opens a small dropdown. Typing in the toolbar's "abbrev" demo
 * input opens the snippet popup (just like the real /hpi trigger).
 */

const { useState: editor_useState } = React;

function EditorArea({ tabs, activeId, onActivate, onClose }) {
  const active = tabs.find(t => t.id === activeId);
  return (
    <div className="part-editor-area">
      <TabStrip tabs={tabs} activeId={activeId} onActivate={onActivate} onClose={onClose} />
      <div className="editor-content">
        {active ? renderEditor(active) : <EmptyEditor />}
      </div>
    </div>
  );
}

function TabStrip({ tabs, activeId, onActivate, onClose }) {
  if (tabs.length === 0) return null;
  return (
    <div className="editor-tabstrip">
      {tabs.map(t => (
        <div
          key={t.id}
          className={`editor-tab ${t.id === activeId ? 'is-active' : ''}`}
          onClick={() => onActivate(t.id)}
        >
          <Icon name="file-text" size={12} />
          <span className="editor-tab-title">{t.title}</span>
          <button
            className={`editor-tab-close ${t.dirty ? 'is-dirty' : ''}`}
            onClick={e => { e.stopPropagation(); onClose(t.id); }}
            aria-label={t.dirty ? 'Unsaved — close tab' : 'Close tab'}
          >
            {t.dirty ? <Icon name="circle" size={8} /> : <Icon name="x" size={12} />}
          </button>
        </div>
      ))}
    </div>
  );
}

function EmptyEditor() {
  return (
    <div className="editor-empty">
      <div className="editor-empty-mark" aria-hidden="true" />
      <h2 className="editor-empty-title">Choose a patient to begin.</h2>
      <p className="editor-empty-line">
        Open the command palette with <span className="editor-empty-key">⌘⇧P</span> or pick a patient from the sidebar.
      </p>
    </div>
  );
}

function renderEditor(tab) {
  if (tab.kind === 'patient') return <PatientNote tab={tab} />;
  if (tab.kind === 'welcome') return <WelcomeDoc />;
  return <div style={{ padding: 24, color: 'var(--color-fg-muted)' }}>Unknown editor.</div>;
}

/* ── Patient note (the headline screen) ──────────────────────────────────── */

function PatientNote({ tab }) {
  const [active, setActive] = editor_useState({ btn: 'bold' });
  const [disposition, setDisposition] = editor_useState('discharge home');
  const [dispOpen, setDispOpen] = editor_useState(false);
  const [duration, setDuration] = editor_useState('3 days');
  const [chiefSelected, setChiefSelected] = editor_useState(false);
  const [snippetPopup, setSnippetPopup] = editor_useState(null); // {x, y, q}
  const dispositions = ['discharge home', 'admit to observation', 'admit inpatient', 'transfer to ED', 'refer to specialist'];
  const allSnippets = [
    { abbrev: 'hpi', label: 'History of Present Illness' },
    { abbrev: 'pmh', label: 'Past Medical History' },
    { abbrev: 'ros', label: 'Review of Systems' },
    { abbrev: 'pe',  label: 'Physical Exam' },
    { abbrev: 'imp', label: 'Impression' },
    { abbrev: 'plan',label: 'Plan' },
    { abbrev: 'disp',label: 'Disposition' },
    { abbrev: 'rx',  label: 'Prescription' },
  ];

  return (
    <div className="ru-edit">
      <div className="ru-edit-toolbar">
        <div className="ru-edit-toolbar-group">
          <button className={`ru-edit-toolbar-btn ${active.btn === 'bold' ? 'is-active' : ''}`} onClick={() => setActive({ btn: 'bold' })}><Icon name="bold" size={13} /></button>
          <button className={`ru-edit-toolbar-btn ${active.btn === 'italic' ? 'is-active' : ''}`} onClick={() => setActive({ btn: 'italic' })}><Icon name="italic" size={13} /></button>
        </div>
        <div className="ru-edit-toolbar-group">
          <button className="ru-edit-toolbar-btn"><Icon name="list" size={13} /></button>
          <button className="ru-edit-toolbar-btn"><Icon name="list-ordered" size={13} /></button>
          <button className="ru-edit-toolbar-btn"><Icon name="quote" size={13} /></button>
        </div>
        <div className="ru-edit-toolbar-group">
          <button className="ru-edit-toolbar-btn"><Icon name="code" size={13} /></button>
        </div>
        <div style={{ flex: 1 }} />
        <div className="ru-edit-toolbar-group" style={{ borderRight: 0 }}>
          <input
            className="inp"
            style={{ width: 200, fontSize: 12, padding: '4px 8px', background: 'var(--color-surface-elevated)' }}
            placeholder="Try /hpi or /disp …"
            onChange={e => {
              const v = e.target.value;
              const m = v.match(/\/(\w*)$/);
              if (m) {
                const r = e.target.getBoundingClientRect();
                setSnippetPopup({ x: r.left, y: r.bottom + 4, q: m[1] });
              } else {
                setSnippetPopup(null);
              }
            }}
            onBlur={() => setTimeout(() => setSnippetPopup(null), 200)}
          />
        </div>
      </div>

      <div className="ru-edit-host">
        <h1>Doe, John — Visit 14 Nov 2026</h1>
        <div className="meta">patient://p-001 · 57 M · Last visit 02 Oct 2026</div>

        <h2>History of Present Illness</h2>
        <p>
          Patient reports{' '}
          <span
            className={`chip text ${chiefSelected ? 'selected' : ''}`}
            onClick={() => setChiefSelected(s => !s)}
            tabIndex={0}
          >cough, low-grade fever</span>
          {' '}and has had symptoms for{' '}
          <span className="chip text" tabIndex={0} onClick={() => {
            const next = prompt('Duration:', duration);
            if (next) setDuration(next);
          }}>{duration}</span>.
          Denies chest pain, shortness of breath at rest, or recent travel.
        </p>

        <h2>Review of Systems</h2>
        <ul>
          <li>Constitutional: low-grade fever, mild fatigue.</li>
          <li>Respiratory: cough productive of clear sputum; no haemoptysis.</li>
          <li>Cardiovascular: no palpitations, no chest pain.</li>
          <li>GI / GU: unremarkable.</li>
        </ul>

        <h2>Impression</h2>
        <p>Likely viral upper respiratory infection. No red flags on exam. Will reassess in 48 h if symptoms persist.</p>

        <h2>Plan &amp; Disposition</h2>
        <p>
          Symptomatic management — paracetamol PRN, hydration. Disposition:{' '}
          <span
            className="chip picklist"
            tabIndex={0}
            onClick={e => {
              const r = e.currentTarget.getBoundingClientRect();
              setDispOpen({ x: r.left, y: r.bottom + 4 });
            }}
          >
            {disposition} <Icon name="chevron-down" size={10} style={{ verticalAlign: 'baseline' }} />
          </span>.
        </p>
      </div>

      {dispOpen && (
        <Popup
          x={dispOpen.x}
          y={dispOpen.y}
          onClose={() => setDispOpen(false)}
        >
          {dispositions.map(d => (
            <div
              key={d}
              className={`snippet-popup-item ${d === disposition ? 'is-sel' : ''}`}
              onClick={() => { setDisposition(d); setDispOpen(false); }}
            >
              <span className="snippet-popup-label">{d}</span>
            </div>
          ))}
        </Popup>
      )}

      {snippetPopup && (
        <Popup x={snippetPopup.x} y={snippetPopup.y} onClose={() => setSnippetPopup(null)}>
          {allSnippets
            .filter(s => !snippetPopup.q || s.abbrev.startsWith(snippetPopup.q.toLowerCase()))
            .map((s, i) => (
              <div key={s.abbrev} className={`snippet-popup-item ${i === 0 ? 'is-sel' : ''}`}>
                <span className="snippet-popup-abbrev">/{s.abbrev}</span>
                <span className="snippet-popup-label">{s.label}</span>
              </div>
            ))}
        </Popup>
      )}
    </div>
  );
}

function Popup({ x, y, onClose, children }) {
  return (
    <div className="snippet-popup" style={{ left: x, top: y }} onMouseDown={e => e.stopPropagation()}>
      {children}
    </div>
  );
}

function WelcomeDoc() {
  return (
    <div className="ru-edit-host">
      <h1>Welcome back.</h1>
      <div className="meta">workspace://my-practice</div>
      <p>Three patients scheduled today. Two notes awaiting signature.</p>
      <p style={{ color: 'var(--color-fg-muted)' }}>
        Press <span className="editor-empty-key">⌘P</span> to open a patient, or <span className="editor-empty-key">⌘⇧P</span> for the command palette.
      </p>
    </div>
  );
}

Object.assign(window, { EditorArea });
