/* Setup — five-step ceremony.
 * Step 1: Sign in (mock Google modal)
 * Step 2: Nickname
 * Step 3: Passphrase + confirm with strength meter
 * Step 4: Recovery code grid + acknowledge
 * Step 5: Finish
 */

const { useState: st_useState } = React;

const STEPS = ['Sign in', 'Nickname', 'Passphrase', 'Recovery', 'Finish'];
const STEP_HEADLINES = {
  1: 'Sign in to Ru-Soam',
  2: 'Choose a nickname',
  3: 'Set your passphrase',
  4: 'Save your recovery code',
  5: 'Setup complete',
};

function ProgressRail({ step }) {
  // Fill the rail proportional to (step - 1) / (n - 1), capped to the rail's [10%..90%] band.
  const completed = Math.max(0, step - 1);
  const pct = `${(completed / (STEPS.length - 1)) * 80}%`;
  return (
    <div>
      <div className="progress-eyebrow">
        <span className="progress-counter">Step <strong>{step}</strong> of {STEPS.length}</span>
        <h3 className="progress-headline">{STEP_HEADLINES[step]}</h3>
      </div>
      <div className="progress-rail" style={{ '--pct': pct }}>
        {STEPS.map((label, i) => {
          const n = i + 1;
          const cls = n < step ? 'is-done' : n === step ? 'is-active' : '';
          return (
            <div key={label} className={`step ${cls}`}>
              <div className="step-node">
                {n < step ? <Icon name="check" size={14} /> : n}
              </div>
              <span className="step-label">{label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function SetupPage({ onFinish, addNew }) {
  const [step, setStep] = st_useState(1);
  const [email, setEmail] = st_useState('');
  const [nickname, setNickname] = st_useState('');
  const [pass, setPass] = st_useState('');
  const [confirm, setConfirm] = st_useState('');
  const [showOAuth, setShowOAuth] = st_useState(false);
  const [ack, setAck] = st_useState(false);

  // fake strength: 0..4 based on length & variety
  function scoreOf(p) {
    if (!p) return 0;
    let s = 0;
    if (p.length >= 8) s++;
    if (p.length >= 12) s++;
    if (/[A-Z]/.test(p) && /[a-z]/.test(p)) s++;
    if (/[0-9]/.test(p) || /[^A-Za-z0-9]/.test(p)) s++;
    return Math.min(s, 4);
  }
  const passScore = scoreOf(pass);
  const passOk = pass.length >= 12 && passScore >= 3 && pass === confirm;

  const recoveryWords = ['tide','cane','knot','river','weave','plain','span','willow','hush','stride','copper','monsoon'];

  return (
    <div className="setup-page">
      <div className="setup-container">
        <ProgressRail step={step} />

        <div className="setup-content">
          {step === 1 && (
            <div className="setup-step">
              <h1 className="setup-title">{addNew ? 'Add a new workspace' : 'Welcome to Ru-Soam'}</h1>
              <Description>{addNew ? 'Sign in to create an additional workspace. Your data stays on this device.' : 'Sign in to create your secure workspace. Your data stays on this device.'}</Description>
              <GoogleBtn onClick={() => setShowOAuth(true)} />
              {showOAuth && (
                <OAuthModal onCancel={() => setShowOAuth(false)} onSuccess={e => { setShowOAuth(false); setEmail(e); setStep(2); }} />
              )}
            </div>
          )}

          {step === 2 && (
            <div className="setup-step">
              <h1 className="setup-title">Choose a nickname</h1>
              <Description>This is a local label for this workspace. It is not shared with anyone.</Description>
              <div>
                <Label htmlFor="nick">Nickname</Label>
                <Input id="nick" value={nickname} onChange={setNickname} autoFocus placeholder="e.g. My Practice" />
                {nickname.length > 0 && (nickname.length < 4 || nickname.length > 64) && (
                  <ErrorLine>Nickname must be 4–64 characters.</ErrorLine>
                )}
              </div>
              <div className="setup-actions">
                <PrimaryBtn disabled={nickname.length < 4} onClick={() => setStep(3)}>Next</PrimaryBtn>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="setup-step">
              <h1 className="setup-title">Set your passphrase</h1>
              <Description>This passphrase encrypts all your data locally. Minimum 12 characters; strength 3/4 required.</Description>
              <div>
                <Label htmlFor="p1">Passphrase</Label>
                <PasswordInput id="p1" value={pass} onChange={setPass} autoFocus autoComplete="new-password" />
                {pass.length > 0 && <div style={{ marginTop: 10 }}><StrengthMeter score={passScore} /></div>}
                {pass.length > 0 && pass.length < 12 && <ErrorLine>Passphrase must be at least 12 characters.</ErrorLine>}
                {pass.length >= 12 && passScore < 3 && <ErrorLine>Passphrase is too weak. Please choose something harder to guess.</ErrorLine>}
              </div>
              <div>
                <Label htmlFor="p2">Confirm passphrase</Label>
                <PasswordInput id="p2" value={confirm} onChange={setConfirm} autoComplete="new-password" />
                {confirm.length > 0 && pass !== confirm && <ErrorLine>Passphrases do not match.</ErrorLine>}
              </div>
              <div className="setup-actions">
                <GhostBtn onClick={() => setStep(2)}>Back</GhostBtn>
                <PrimaryBtn disabled={!passOk} onClick={() => setStep(4)}>Next</PrimaryBtn>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="setup-step">
              <h1 className="setup-title">Save your recovery code</h1>
              <Description>These 12 words are the only way to recover your workspace if you forget your passphrase or lose this device. Store them somewhere safe offline.</Description>
              <div className="recovery-grid">
                {recoveryWords.map((w, i) => (
                  <div key={i} className="recovery-word">
                    <span className="recovery-index">{i+1}.</span>
                    <span className="recovery-text">{w}</span>
                  </div>
                ))}
              </div>
              <GhostBtn className="btn-show" onClick={() => navigator.clipboard?.writeText(recoveryWords.join(' '))}>
                <Icon name="copy" size={12} /> Copy to clipboard
              </GhostBtn>
              <label className="ack">
                <input type="checkbox" checked={ack} onChange={e => setAck(e.target.checked)} />
                I have recorded these words. I understand they are the only way to recover access if I forget my passphrase or lose this device.
              </label>
              <div className="setup-actions">
                <PrimaryBtn disabled={!ack} onClick={() => setStep(5)}>Continue</PrimaryBtn>
              </div>
            </div>
          )}

          {step === 5 && (
            <div className="setup-step">
              <h1 className="setup-title">Setup complete</h1>
              <Description>Your workspace is ready. Click <strong>Finish setup</strong> to open it.</Description>
              <div className="setup-actions">
                <PrimaryBtn onClick={() => onFinish({ email, nickname })}>Finish setup</PrimaryBtn>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function OAuthModal({ onSuccess, onCancel }) {
  const [v, setV] = st_useState('');
  const [err, setErr] = st_useState('');
  return (
    <div className="modal-overlay" role="dialog" aria-modal="true">
      <div className="modal-card">
        <div className="modal-header">
          <GoogleG />
          <h2 className="modal-title">Sign in with Google</h2>
          <p className="modal-subtitle">(mock — real OAuth lands in a future release)</p>
        </div>
        <div>
          <Label htmlFor="oem">Email address</Label>
          <Input id="oem" type="email" value={v} onChange={x => { setV(x); setErr(''); }} placeholder="you@example.com" autoFocus error={!!err} />
          {err && <ErrorLine>{err}</ErrorLine>}
        </div>
        <div className="modal-actions">
          <GhostBtn onClick={onCancel}>Cancel</GhostBtn>
          <PrimaryBtn onClick={() => {
            if (!/.+@.+\..+/.test(v.trim())) { setErr('Please enter a valid email address.'); return; }
            onSuccess(v.trim());
          }}>Sign in</PrimaryBtn>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { SetupPage });
