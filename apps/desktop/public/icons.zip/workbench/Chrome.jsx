/* Chrome — TitleBar, ActivityBar, PrimarySideBar, StatusBar.
 * The TitleBar carries the wordmark; the ActivityBar swaps sidebar contents.
 */

const { useState, useEffect, useRef } = React;

function TitleBar({ avatar, activeResource = 'Doe, J. — Visit 14 Nov 2026', onTogglePrimary, onTogglePanel, onToggleAux, onOpenQuick }) {
  const [openMenu, setOpenMenu] = React.useState(null);
  const menus = ['File', 'Edit', 'View', 'Patient', 'Snippets', 'Window', 'Help'];
  return (
    <div className="part-titlebar">
      {/* App icon — cane suspension bridge.
       * DEFAULT renders the solid bridge silhouette (glyph mode).
       * body[data-icon-mode="tile"] opts back into the stroked mark on the
       * accent-filled cell (preserved for the A/B comparison pages).
       */}
      <div className="tb-app" title="Ru-Soam">
        {document.body.dataset.iconMode === 'tile' ? (
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M5 5v12" />
            <path d="M19 5v12" />
            <path d="M3 17h18" />
            <path d="M5 7 Q 12 14 19 7" />
            <path d="M9 11.4v5.6" strokeWidth="1.2" />
            <path d="M12 12.4v4.6" strokeWidth="1.2" />
            <path d="M15 11.4v5.6" strokeWidth="1.2" />
          </svg>
        ) : (
          <svg width="20" height="20" viewBox="0 0 64 64" fill="currentColor" aria-hidden="true">
            <rect x="9" y="10" width="6" height="38" rx="2" />
            <rect x="49" y="10" width="6" height="38" rx="2" />
            <rect x="5" y="46" width="54" height="5" rx="1.5" />
            <path d="M12 14 Q 32 44 52 14 L 52 18 Q 32 38 12 18 Z" />
            <rect x="22" y="28" width="2" height="18" rx="1" />
            <rect x="31" y="32" width="2" height="14" rx="1" />
            <rect x="40" y="28" width="2" height="18" rx="1" />
          </svg>
        )}
      </div>

      {/* Menu strip */}
      <div className="tb-menu">
        {menus.map(m => (
          <button
            key={m}
            className={`tb-menu-item ${openMenu === m ? 'is-open' : ''}`}
            onClick={() => setOpenMenu(openMenu === m ? null : m)}
          >{m}</button>
        ))}
      </div>

      <div className="titlebar-drag-region tb-flex" />

      {/* Back / forward */}
      <div className="tb-nav">
        <button className="tb-icon-btn" aria-label="Go back" title="Back"><Icon name="arrow-left" size={14} /></button>
        <button className="tb-icon-btn" aria-label="Go forward" title="Forward" disabled><Icon name="arrow-right" size={14} /></button>
      </div>

      {/* Quick-open pill */}
      <button className="quick-open" onClick={onOpenQuick} title="Quick open · ⌘P">
        <span className="lead"><Icon name="search" size={13} /></span>
        <span className="label">{activeResource}</span>
        <span className="meta">⌘P</span>
        <span className="trail"><Icon name="chevron-down" size={12} /></span>
      </button>

      <div className="titlebar-drag-region tb-flex" />

      {/* Right cluster */}
      <div className="tb-right">
        <button className="tb-icon-btn" title="Toggle Primary Side Bar" onClick={onTogglePrimary}><Icon name="panel-left" size={14} /></button>
        <button className="tb-icon-btn" title="Toggle Panel" onClick={onTogglePanel}><Icon name="panel-bottom" size={14} /></button>
        <button className="tb-icon-btn" title="Toggle Auxiliary Side Bar" onClick={onToggleAux}><Icon name="panel-right" size={14} /></button>
        <span className="tb-divider" aria-hidden="true" />
        {avatar}
        <div className="tb-win">
          <button className="tb-win-btn" aria-label="Minimize"><Icon name="minus" size={12} /></button>
          <button className="tb-win-btn" aria-label="Maximize"><Icon name="square" size={10} /></button>
          <button className="tb-win-btn is-close" aria-label="Close"><Icon name="x" size={12} /></button>
        </div>
      </div>
    </div>
  );
}

const ACTIVITIES = [
  { id: 'patients', icon: 'circle-user', label: 'Patients' },
  { id: 'snippets', icon: 'hash', label: 'Snippets' },
  { id: 'search',   icon: 'search', label: 'Search' },
];

function ActivityBar({ active, onSelect }) {
  return (
    <div className="part-activitybar" role="navigation" aria-label="Activity Bar">
      {ACTIVITIES.map(a => (
        <button
          key={a.id}
          className={`act-btn ${active === a.id ? 'is-active' : ''}`}
          onClick={() => onSelect(a.id)}
          title={a.label}
          aria-label={a.label}
        >
          <Icon name={a.icon} size={18} />
        </button>
      ))}
      <div className="act-spacer" />
      <button className="act-btn" title="Settings" aria-label="Settings">
        <Icon name="settings" size={18} />
      </button>
    </div>
  );
}

function PrimarySideBar({ activity, activeTabResource, onOpen }) {
  if (activity === 'patients') return <PatientsSideBar activeTabResource={activeTabResource} onOpen={onOpen} />;
  if (activity === 'snippets') return <SnippetsSideBar />;
  if (activity === 'search')   return <SearchSideBar />;
  return null;
}

function PatientsSideBar({ activeTabResource, onOpen }) {
  const patients = [
    { id: 'p-001', name: 'Doe, J.',      meta: '57 M',   today: true,  resource: 'patient://p-001' },
    { id: 'p-002', name: 'Tamang, S.',   meta: '34 F',   today: true,  resource: 'patient://p-002' },
    { id: 'p-003', name: 'Khaling, P.',  meta: '8 M',    today: true,  resource: 'patient://p-003' },
    { id: 'p-004', name: 'Lepcha, A.',   meta: '72 F',   today: false, resource: 'patient://p-004' },
    { id: 'p-005', name: 'Sherpa, T.',   meta: '29 M',   today: false, resource: 'patient://p-005' },
    { id: 'p-006', name: 'Rai, N.',      meta: '45 F',   today: false, resource: 'patient://p-006' },
  ];
  const today = patients.filter(p => p.today);
  const earlier = patients.filter(p => !p.today);
  return (
    <div className="part-sidebar part-sidebar-primary" aria-label="Primary Side Bar">
      <div className="sidebar-header">
        <span>Patients</span>
        <div className="sidebar-header-actions">
          <button className="sidebar-icon-btn" title="Add patient"><Icon name="plus" size={14} /></button>
        </div>
      </div>
      <div className="sidebar-search" style={{ position: 'relative' }}>
        <span style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--color-fg-muted)', pointerEvents: 'none' }}>
          <Icon name="search" size={13} />
        </span>
        <input className="inp" style={{ paddingLeft: 30, fontSize: 12 }} placeholder="Filter…" />
      </div>
      <div className="sidebar-group">Today · {today.length}</div>
      <ul className="sidebar-list">
        {today.map(p => (
          <li
            key={p.id}
            className={`sidebar-item ${activeTabResource === p.resource ? 'is-active' : ''}`}
            onClick={() => onOpen?.({ resource: p.resource, title: p.name })}
          >
            <Icon name="file-text" size={14} />
            <span>{p.name}</span>
            <span className="sidebar-item-meta">{p.meta}</span>
          </li>
        ))}
      </ul>
      <div className="sidebar-group">Earlier</div>
      <ul className="sidebar-list">
        {earlier.map(p => (
          <li
            key={p.id}
            className={`sidebar-item ${activeTabResource === p.resource ? 'is-active' : ''}`}
            onClick={() => onOpen?.({ resource: p.resource, title: p.name })}
          >
            <Icon name="file-text" size={14} />
            <span>{p.name}</span>
            <span className="sidebar-item-meta">{p.meta}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function SnippetsSideBar() {
  const snippets = [
    { abbrev: 'hpi',   label: 'History of Present Illness' },
    { abbrev: 'pmh',   label: 'Past Medical History' },
    { abbrev: 'ros',   label: 'Review of Systems' },
    { abbrev: 'pe',    label: 'Physical Exam' },
    { abbrev: 'imp',   label: 'Impression' },
    { abbrev: 'plan',  label: 'Plan' },
    { abbrev: 'disp',  label: 'Disposition' },
    { abbrev: 'rx',    label: 'Prescription' },
  ];
  return (
    <div className="part-sidebar part-sidebar-primary">
      <div className="sidebar-header">
        <span>Snippets</span>
        <div className="sidebar-header-actions">
          <button className="sidebar-icon-btn" title="New snippet"><Icon name="plus" size={14} /></button>
        </div>
      </div>
      <ul className="sidebar-list">
        {snippets.map(s => (
          <li key={s.abbrev} className="sidebar-item">
            <Icon name="hash" size={14} />
            <span>{s.label}</span>
            <span className="sidebar-item-meta">/{s.abbrev}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function SearchSideBar() {
  return (
    <div className="part-sidebar part-sidebar-primary">
      <div className="sidebar-header"><span>Search</span></div>
      <div className="sidebar-search">
        <input className="inp" placeholder="Search patient notes…" style={{ fontSize: 12 }} />
      </div>
      <p className="sidebar-empty-state">Type a query above to search every note in this workspace.</p>
    </div>
  );
}

function StatusBar({ locked, nickname, onToggleLock, devMode, alerts = 0 }) {
  return (
    <div className="part-statusbar" role="status" aria-label="Status Bar">
      {/* LEFT — identity & state */}
      <div className="statusbar-region left">
        <button
          className="statusbar-entry"
          onClick={onToggleLock}
          title={locked ? 'Workspace locked — enter passphrase to unlock' : 'Workspace unlocked — click to lock'}
        >
          <Icon name={locked ? 'lock' : 'unlock'} size={12} />
          <span>{locked ? 'Locked' : 'Unlocked'}</span>
        </button>
        {nickname && (
          <span className="statusbar-entry" title="Active workspace">
            <Icon name="circle-user" size={12} />
            <span>{nickname}</span>
          </span>
        )}
        <span className="statusbar-entry" title="Workspace entity ID">
          <Icon name="hash" size={12} />
          <span>entity-mock-001</span>
        </span>
        <span className="sb-divider" aria-hidden="true" />
        <span className="statusbar-entry is-ok" title="All changes saved">
          <Icon name="check" size={12} />
          <span>Saved 2m ago</span>
        </span>
      </div>

      {/* RIGHT — cursor → encoding → dev → alerts (corner) */}
      <div className="statusbar-region right">
        <span className="statusbar-entry" title="Cursor position">Ln 14, Col 2</span>
        <span className="statusbar-entry" title="File encoding">UTF-8</span>
        <span className="sb-divider" aria-hidden="true" />
        {devMode && (
          <span className="statusbar-entry is-warning" title="Development build">
            <Icon name="triangle-alert" size={12} />
            <span>Dev build</span>
          </span>
        )}
        <button className="statusbar-entry" title={`${alerts} unread`}>
          <Icon name="bell" size={12} />
          <span>Alerts</span>
          {alerts > 0 && <span className="sb-badge">{alerts}</span>}
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { TitleBar, ActivityBar, PrimarySideBar, StatusBar });
