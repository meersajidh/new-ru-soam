/* UnlockGate — passphrase entry, with a recovery-code fallback. */

const { useState: gt_useState } = React;

function UnlockGate({ nickname, onUnlock }) {
  const [mode, setMode] = gt_useState('passphrase'); // 'passphrase' | 'recovery'
  const [pass, setPass] = gt_useState('');
  const [recovery, setRecovery] = gt_useState('');
  const [err, setErr] = gt_useState('');

  return (
    <div className="gate-overlay">
      <div className="gate-card">
        <div>
          <h2 className="gate-title"><Icon name="lock" size={20} /> Workspace locked</h2>
          {nickname && <p className="gate-nickname">{nickname}</p>}
        </div>

        {mode === 'passphrase' && (
          <form className="gate-form" onSubmit={e => { e.preventDefault(); if (!pass) return; if (pass === 'wrong') { setErr('Incorrect passphrase (2 attempts remaining).'); return; } onUnlock(); }}>
            <div>
              <Label htmlFor="gp">Passphrase</Label>
              <PasswordInput id="gp" value={pass} onChange={v => { setPass(v); setErr(''); }} autoFocus placeholder="Enter your passphrase" />
              {err && <ErrorLine>{err}</ErrorLine>}
            </div>
            <div className="setup-actions">
              <PrimaryBtn disabled={!pass} type="submit">Unlock</PrimaryBtn>
            </div>
            <button type="button" className="gate-recovery-toggle" onClick={() => setMode('recovery')}>
              Use recovery code instead
            </button>
          </form>
        )}

        {mode === 'recovery' && (
          <form className="gate-form" onSubmit={e => { e.preventDefault(); const words = recovery.trim().split(/\s+/).filter(Boolean); if (words.length !== 12) { setErr(`Expected 12 words, got ${words.length}.`); return; } onUnlock(); }}>
            <Label htmlFor="rec">Recovery code (12 words, space-separated)</Label>
            <textarea
              id="rec"
              className="inp"
              style={{ fontFamily: 'var(--font-mono)', fontSize: 12, minHeight: 80, resize: 'vertical' }}
              value={recovery}
              onChange={e => { setRecovery(e.target.value); setErr(''); }}
              placeholder="word1 word2 word3 … word12"
              rows={3}
              autoFocus
            />
            {err && <ErrorLine>{err}</ErrorLine>}
            <div className="setup-actions">
              <GhostBtn onClick={() => { setMode('passphrase'); setErr(''); }}>Back</GhostBtn>
              <PrimaryBtn disabled={!recovery.trim()} type="submit">Unlock with recovery code</PrimaryBtn>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { UnlockGate });
