/* App — top-level orchestrator + screen switcher.
 *
 * Screens (the four product surfaces, click-through):
 *   workbench → the unlocked workbench with tabs, sidebar, snippet editor, palette
 *   gate      → the locked-workspace gate (passphrase / recovery code)
 *   picker    → the workspace picker
 *   setup     → the five-step setup ceremony
 *
 * A floating switcher in the bottom-right lets the user (or anyone reviewing
 * the kit) jump between screens. This is NOT part of the product — it exists
 * only because the kit is one HTML file that shows every surface.
 */

const { useState: app_useState, useEffect: app_useEffect } = React;

function App() {
  const [screen, setScreen] = app_useState('workbench');
  return (
    <>
      {screen === 'workbench' && <WorkbenchScreen onLock={() => setScreen('gate')} onSignOut={() => setScreen('picker')} />}
      {screen === 'gate'      && <GateScreen onUnlock={() => setScreen('workbench')} />}
      {screen === 'picker'    && <PickerScreen onSelect={() => setScreen('gate')} onAddNew={() => setScreen('setup')} />}
      {screen === 'setup'     && <SetupScreen onFinish={() => setScreen('workbench')} />}
      <Switcher current={screen} onChange={setScreen} />
    </>
  );
}

function Switcher({ current, onChange }) {
  const screens = [
    { id: 'workbench', label: 'Workbench' },
    { id: 'gate',      label: 'Gate' },
    { id: 'picker',    label: 'Picker' },
    { id: 'setup',     label: 'Setup' },
  ];
  return (
    <div className="demo-switcher">
      {screens.map(s => (
        <button
          key={s.id}
          className={current === s.id ? 'is-active' : ''}
          onClick={() => onChange(s.id)}
        >{s.label}</button>
      ))}
    </div>
  );
}

/* ── Workbench screen — TitleBar / ActivityBar / Sidebar / Editor / Palette / Status */

function WorkbenchScreen({ onLock, onSignOut }) {
  const [tabs, setTabs] = app_useState([
    { id: 't1', title: 'Welcome',     resource: 'view://welcome',     kind: 'welcome', dirty: false },
    { id: 't2', title: 'Doe, J.',     resource: 'patient://p-001',    kind: 'patient', dirty: true  },
    { id: 't3', title: 'Tamang, S.',  resource: 'patient://p-002',    kind: 'patient', dirty: false },
  ]);
  const [activeId, setActiveId] = app_useState('t2');
  const [activity, setActivity] = app_useState('patients');
  const [paletteOpen, setPaletteOpen] = app_useState(false);

  app_useEffect(() => {
    function onKey(e) {
      if ((e.metaKey || e.ctrlKey) && e.shiftKey && (e.key === 'p' || e.key === 'P')) {
        e.preventDefault();
        setPaletteOpen(true);
      }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  function openTab({ resource, title }) {
    const existing = tabs.find(t => t.resource === resource);
    if (existing) { setActiveId(existing.id); return; }
    const id = 't' + (tabs.length + 1) + '-' + Date.now();
    setTabs([...tabs, { id, title, resource, kind: 'patient', dirty: false }]);
    setActiveId(id);
  }

  function closeTab(id) {
    const idx = tabs.findIndex(t => t.id === id);
    if (idx < 0) return;
    const next = tabs.filter(t => t.id !== id);
    setTabs(next);
    if (activeId === id) {
      setActiveId(next[Math.max(0, idx - 1)]?.id || null);
    }
  }

  const activeResource = tabs.find(t => t.id === activeId)?.resource;

  return (
    <div className="workbench">
      <TitleBar avatar={<UserAvatar email="dr.maya@example.com" nickname="My Practice" onRelock={onLock} onSignOut={onSignOut} />} />
      <div className="part-middle">
        <ActivityBar active={activity} onSelect={setActivity} />
        <PrimarySideBar activity={activity} activeTabResource={activeResource} onOpen={openTab} />
        <div className="middle-center">
          <EditorArea tabs={tabs} activeId={activeId} onActivate={setActiveId} onClose={closeTab} />
        </div>
      </div>
      <StatusBar locked={false} nickname="My Practice" devMode alerts={2} onToggleLock={onLock} />
      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} />
    </div>
  );
}

/* ── Gate screen — locked workspace wraps in the workbench shell */
function GateScreen({ onUnlock }) {
  return (
    <div className="workbench">
      <TitleBar />
      <div className="part-middle" style={{ alignItems: 'stretch' }}>
        <UnlockGate nickname="My Practice" onUnlock={onUnlock} />
      </div>
      <StatusBar locked nickname="" devMode />
    </div>
  );
}

/* ── Picker screen — full-screen route */
function PickerScreen({ onSelect, onAddNew }) {
  const workspaces = [
    { id: 'ws-1', nickname: 'My Practice',     lastSeen: 'Last opened 18 Nov 2026', noteCount: 284 },
    { id: 'ws-2', nickname: 'Locum Hours',     lastSeen: 'Last opened 2 hours ago', noteCount: 47  },
    { id: 'ws-3', nickname: 'Research Cohort', lastSeen: 'Last opened 2 Mar 2026',  noteCount: 1204 },
  ];
  return (
    <div className="workbench">
      <TitleBar />
      <div className="part-middle" style={{ alignItems: 'stretch' }}>
        <WorkspacePicker workspaces={workspaces} onSelect={onSelect} onAddNew={onAddNew} activeId="ws-2" />
      </div>
      <StatusBar locked nickname="" devMode />
    </div>
  );
}

/* ── Setup screen — full-screen route */
function SetupScreen({ onFinish }) {
  return (
    <div className="workbench">
      <TitleBar />
      <div className="part-middle" style={{ alignItems: 'stretch' }}>
        <SetupPage onFinish={onFinish} addNew={false} />
      </div>
      <StatusBar locked={false} nickname="" devMode={false} />
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
